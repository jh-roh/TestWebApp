﻿namespace DotNetNote.Services
{
    /// <summary>
    /// 인터페이스
    /// </summary>
    public interface ICopyrightService
    {
        string GetCopyrightString();
    }
}
