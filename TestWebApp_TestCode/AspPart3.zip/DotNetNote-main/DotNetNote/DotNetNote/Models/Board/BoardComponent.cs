﻿using System;

public class BoardComponent
{

}

