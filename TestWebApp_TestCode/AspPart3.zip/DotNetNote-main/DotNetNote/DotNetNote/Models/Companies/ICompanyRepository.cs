﻿using Dul.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetNote.Models.Companies
{
    public interface ICompanyRepository : IBreadShop<CompanyModel>
    {

    }
}
