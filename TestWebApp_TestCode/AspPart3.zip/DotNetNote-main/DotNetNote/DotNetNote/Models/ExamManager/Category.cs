﻿//using System.Collections.Generic;

//namespace DotNetNote.Models
//{
//    // 모델 클래스: Category, CategoryModel, CategoryViewModel, CategoryDto, ...
//    public class Category
//    {
//        public int CategoryId { get; set; }
//        public string CategoryName { get; set; }

//        public string Name { get; set;  }

//        private IList<Product> _products = new List<Product>();

//        public IList<Product> Products
//        {
//            get { return _products;  }
//            set { _products = value; }
//        }
//    }
//}
