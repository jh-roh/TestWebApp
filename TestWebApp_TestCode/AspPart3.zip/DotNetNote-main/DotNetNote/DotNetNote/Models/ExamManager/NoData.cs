﻿namespace DotNetNote.Models
{
    public class NoData
    {
        public string Message { get; set; }
    }
}
