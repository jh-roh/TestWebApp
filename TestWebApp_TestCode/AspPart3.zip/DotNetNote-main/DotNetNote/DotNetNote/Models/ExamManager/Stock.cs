﻿namespace DotNetNote.Models
{
    public class Stock
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public double LastPrice { get; set; }
    }
}
