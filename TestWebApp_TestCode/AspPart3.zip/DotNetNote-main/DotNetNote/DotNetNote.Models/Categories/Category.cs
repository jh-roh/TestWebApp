﻿namespace DotNetNote.Models
{
    // 모델 클래스: Category, CategoryModel, CategoryViewModel, CategoryDto, ...
    public class Category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
