﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetNote.Models
{
    public class Buyer
    {
        public int Id { get; set; }
        public string BuyerId { get; set; }
        public string BuyerName { get; set; }
        public string BuyerCode { get; set; }
    }
}
