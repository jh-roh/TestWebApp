﻿CREATE TABLE [dbo].[Threes]
(
	[Id] INT NOT NULL PRIMARY KEY Identity(1, 1),
	[Note] NVarChar(Max) Null
)
Go
