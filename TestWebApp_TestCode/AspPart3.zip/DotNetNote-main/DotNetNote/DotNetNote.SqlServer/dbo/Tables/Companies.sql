﻿CREATE TABLE [dbo].[Companies]
(
	[Id] BIGINT NOT NULL PRIMARY KEY Identity(1, 1),
	Name NVarChar(255) Not Null
)
Go
