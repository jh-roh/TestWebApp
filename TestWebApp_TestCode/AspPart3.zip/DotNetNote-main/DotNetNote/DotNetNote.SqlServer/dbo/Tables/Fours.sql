﻿CREATE TABLE [dbo].[Fours]
(
	[Id] INT NOT NULL PRIMARY KEY Identity(1, 1),
	[Note] NVarChar(Max) Null
)
