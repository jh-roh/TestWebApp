﻿CREATE TABLE [dbo].[Fives]
(
	[Id] INT NOT NULL PRIMARY KEY Identity(1, 1),
	[Note] NVarChar(Max) Not Null
)
