﻿namespace DotNetNote.Enums
{
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }
}
