﻿namespace DotNetNote.Models
{
    public class One
    {
        public int Id { get; set; }
        public string Note { get; set; }
    }
}
