﻿namespace DotNetNote.Models
{
    public class DemoModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
