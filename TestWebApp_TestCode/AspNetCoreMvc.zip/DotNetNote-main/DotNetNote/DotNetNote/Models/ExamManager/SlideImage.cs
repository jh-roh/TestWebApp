﻿namespace DotNetNote.Models
{
    public class SlideImage
    {
        public string Url { get; set; }
        public string Caption { get; set; }
    }
}
