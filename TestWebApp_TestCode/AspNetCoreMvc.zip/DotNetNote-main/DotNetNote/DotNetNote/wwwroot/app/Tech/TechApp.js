﻿(function () {
    'use strict';

    angular.module('TechApp', [
        // Angular modules 

        // Custom modules 

        // 3rd Party Modules
        
    ]);
})();
