﻿namespace DotNetNote.Services
{
    public class InfoService : IInfoService
    {
        public string GetUrl()
        {
            return "http://www.gilbut.co.kr";
        }
    }
}
