﻿namespace DotNetNote.Services
{
    public interface IInfoService
    {
        string GetUrl();
    }
}