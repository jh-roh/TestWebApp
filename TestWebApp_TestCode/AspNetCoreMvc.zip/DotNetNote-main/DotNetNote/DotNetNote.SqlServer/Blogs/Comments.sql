﻿CREATE TABLE [dbo].[Comments]
(
	[Id] INT NOT NULL PRIMARY KEY
)
