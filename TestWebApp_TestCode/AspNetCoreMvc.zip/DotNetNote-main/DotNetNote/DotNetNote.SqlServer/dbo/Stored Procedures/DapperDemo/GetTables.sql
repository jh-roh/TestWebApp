﻿CREATE PROCEDURE [dbo].[GetTables]
AS
	Select [Id], [Note] From Tables 
Go
