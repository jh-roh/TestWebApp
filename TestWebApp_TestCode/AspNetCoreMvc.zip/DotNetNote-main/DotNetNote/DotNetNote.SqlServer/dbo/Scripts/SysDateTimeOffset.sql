﻿-- DateTimeOffset(7)에 대한 기본 값 
Select  SYSDATETIMEOFFSET()
