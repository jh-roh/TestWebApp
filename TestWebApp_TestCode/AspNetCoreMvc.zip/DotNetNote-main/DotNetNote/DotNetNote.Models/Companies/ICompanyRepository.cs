﻿using Dul.Data;

namespace DotNetNote.Models
{
    public interface ICompanyRepository : IBreadShop<CompanyModel>
    {

    }
}
