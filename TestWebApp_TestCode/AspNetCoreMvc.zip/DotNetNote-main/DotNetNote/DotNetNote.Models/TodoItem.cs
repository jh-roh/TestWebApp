﻿namespace DotNetNote.Models
{
    /// <summary>
    /// TODO 리스트
    /// </summary>
    public class TodoItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public bool IsDone { get; set; }
    }
}
