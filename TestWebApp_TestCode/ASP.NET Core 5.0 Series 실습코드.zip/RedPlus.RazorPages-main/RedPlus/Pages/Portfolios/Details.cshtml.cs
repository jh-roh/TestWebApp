using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RedPlus.Pages.Portfolios
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
