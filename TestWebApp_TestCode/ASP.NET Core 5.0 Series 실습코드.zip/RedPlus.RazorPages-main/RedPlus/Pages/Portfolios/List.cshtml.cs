using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RedPlus.Pages.Portfolios
{
    public class ListModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
