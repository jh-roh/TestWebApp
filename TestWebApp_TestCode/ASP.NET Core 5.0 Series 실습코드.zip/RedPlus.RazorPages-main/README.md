# RedPlus.RazorPages

ASP.NET Core Razor Pages 강의 소스 모음


## ASP.NET Core Razor Pages

ASP.NET Core Razor Pages를 사용하여 간단한 블로그 입, 출력을 진행합니다.


## ASP.NET Core - Razor Pages 관련 전체 강좌는 다음 링크로 서비스 됩니다.

https://www.youtube.com/watch?v=xRz2DA8bbbc&list=PLO56HZSjrPTDtR6uKaE7mThbGAUgzvTJe

