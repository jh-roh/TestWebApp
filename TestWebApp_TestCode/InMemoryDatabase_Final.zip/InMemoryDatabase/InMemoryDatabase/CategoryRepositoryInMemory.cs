﻿using Dul.Data;
using System;
using System.Collections.Generic;
using System.Linq; 

namespace InMemoryDatabase
{
    public class CategoryRepositoryInMemory : ICategoryRepository
    {
        private static List<Category> _categories = new List<Category>();
        
        public CategoryRepositoryInMemory()
        {
            _categories = new List<Category>() {
                new Category() { CategoryId = 1, CategoryName = "좋은 책" },
                new Category() { CategoryId = 2, CategoryName = "좋은 강의" },
                new Category() { CategoryId = 3, CategoryName = "좋은 컴퓨터" }
            };            
        }

        public Category Add(Category model)
        {
            _categories.Add(model);
            return model; 
        }

        public Category Browse(int id)
        {
            return _categories.Where(c => c.CategoryId == id).SingleOrDefault(); 
        }

        public void Delete(int id)
        {
            _categories.RemoveAll(c => c.CategoryId == id); 
        }

        public Category Edit(Category model)
        {
            return _categories
                .Where(c => c.CategoryId == model.CategoryId)
                .Select(c => { c.CategoryName = model.CategoryName; return c; })
                .SingleOrDefault();
        }

        public int Has()
        {
            return _categories.Count;
        }

        /// <summary>
        /// 정렬
        /// </summary>
        /// <param name="sortOrder">SortOrder 열거형</param>
        /// <returns>읽기전용(IEnumerable)으로 정렬된 레코드셋</returns>
        public IEnumerable<Category> Ordering(SortOrder sortOrder)
        {
            IEnumerable<Category> categories; 

            switch (sortOrder)
            {
                case SortOrder.Ascending:
                    //[a] 확장 메서드 사용
                    categories = _categories.OrderBy(c => c.CategoryName);
                    break;
                case SortOrder.Descending:
                    //[b] 쿼리 식 사용
                    categories = (from category in _categories
                                 orderby category.CategoryName descending
                                 select category);
                    break;
                default:
                    //[c] 기본 값
                    categories = _categories; 
                    break;
            }

            return categories;
        }

        /// <summary>
        /// 페이징
        /// </summary>
        /// <param name="pageNumber">페이지 번호: 1, 2, 3, ...</param>
        /// <param name="pageSize">페이지 크기: 한 페이지 당 10개씩 표시</param>
        /// <returns>읽고 쓰기가 가능한(List) 페이징 처리된 레코드셋</returns>
        public List<Category> Paging(int pageNumber = 1, int pageSize = 10)
        {
            return 
                _categories
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToList(); 
        }

        public List<Category> Read()
        {
            // 리스트
            return _categories;
        }

        public List<Category> Search(string query)
        {
            return _categories.Where(
                category => category.CategoryName.Contains(query)).ToList();
        }
    }
}
