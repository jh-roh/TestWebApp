﻿C# 2018 프로그래밍 고급 주제 살펴보기 - OOP, 디자인 패턴, 라이브러리 등

- CRUD
- 모델 클래스, 뷰모델 클래스
- 리포지토리(Repository) 패턴
- 클래스, 인터페이스, 열거형
- 제네릭 인터페이스
- 인터페이스 상속
- List<T>와 IEnumerable<T>
- LINQ
- 확장 메서드, 쿼리 식
- 리팩터링
- .NET Framework, .NET Core, .NET Standard
- 나만의 라이브러리 또는 프레임워크 만들기
